/**
 * VeriFace — /upload Route
 * =========================
 * This is how you wire the ML engine into your Express app.
 * Drop this into your router setup.
 *
 * npm install multer express
 * npm install --save-dev @types/multer @types/express
 */

import { Router, Request, Response } from "express";
import multer from "multer";
import { analyzeImage } from "../ml/scoreBlender";

const router = Router();

// ── Multer: memory storage (no disk writes, pure Buffer) ──────────────────────
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10 MB max — matches frontend limit
  },
  fileFilter: (_req, file, cb) => {
    const allowed = ["image/jpeg", "image/png", "image/webp", "image/avif"];
    if (allowed.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error(`Unsupported format: ${file.mimetype}. Use JPEG, PNG, or WEBP.`));
    }
  },
});

// ── POST /upload ───────────────────────────────────────────────────────────────
router.post("/upload", upload.single("image"), async (req: Request, res: Response) => {
  if (!req.file) {
    return res.status(400).json({ error: "No image file provided." });
  }

  try {
    const result = await analyzeImage(req.file.buffer);

    return res.json({
      success:        true,
      aiConfidence:   result.aiConfidence,   // 0–100
      realConfidence: result.realConfidence, // 0–100
      label:          result.label,           // "ai_generated" | "real"
      explanation:    result.explanation,
      signals:        result.signals,         // raw signal breakdown
      processingMs:   result.totalMs,
    });
  } catch (err) {
    console.error("[VeriFace] Inference error:", err);
    return res.status(500).json({
      error: "Analysis failed. Please try a different image.",
    });
  }
});

export default router;

/**
 * ─── Expected JSON Response Shape ───────────────────────────────────────────
 *
 * {
 *   "success": true,
 *   "aiConfidence": 94,
 *   "realConfidence": 6,
 *   "label": "ai_generated",
 *   "explanation": "VeriFace is 94% confident this is AI-generated. Detected signals: ...",
 *   "signals": {
 *     "modelScore":     0.961,
 *     "elaScore":       0.712,
 *     "frequencyScore": 0.683,
 *     "blendedRaw":     0.9098
 *   },
 *   "processingMs": 780
 * }
 */
