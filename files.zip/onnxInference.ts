/**
 * VeriFace — ONNX Inference Engine
 * ==================================
 * Loads the fine-tuned ViT .onnx model and runs CPU inference.
 * Input  : raw image Buffer (any format sharp can decode)
 * Output : { realScore, aiScore, label, inferenceMs }
 *
 * npm install onnxruntime-node sharp
 */

import * as ort from "onnxruntime-node";
import sharp from "sharp";
import path from "path";

// ─── Constants ────────────────────────────────────────────────────────────────

const MODEL_PATH =
  process.env.MODEL_PATH ?? path.join(__dirname, "../../model/veriface.onnx");

/** ViT-base-patch16-224 ImageNet normalization constants */
const NORM_MEAN = [0.485, 0.456, 0.406] as const; // RGB
const NORM_STD  = [0.229, 0.224, 0.225] as const;
const IMAGE_SIZE = 224;
const CHANNELS   = 3;
const TENSOR_LEN = CHANNELS * IMAGE_SIZE * IMAGE_SIZE; // 150,528 floats

// ─── Singleton session (loaded once, reused for all requests) ─────────────────

let _session: ort.InferenceSession | null = null;

async function getSession(): Promise<ort.InferenceSession> {
  if (_session) return _session;

  const opts = new ort.SessionOptions();
  // Max-level graph optimization — fuses ops, removes dead nodes
  opts.graphOptimizationLevel = "all";
  // Use all available logical CPU cores for parallelism
  opts.intraOpNumThreads = Math.max(1, (require("os").cpus() as unknown[]).length);
  opts.interOpNumThreads = 2;
  // CPU EP is the only EP we need — no GPU dependency
  opts.executionProviders = ["cpu"];

  console.log(`[VeriFace] Loading ONNX model from: ${MODEL_PATH}`);
  _session = await ort.InferenceSession.create(MODEL_PATH, opts);
  console.log(`[VeriFace] ✅ Model loaded. Inputs: ${_session.inputNames}`);
  return _session;
}

// ─── Types ────────────────────────────────────────────────────────────────────

export interface OnnxResult {
  /** 0–1 probability the image is a real photograph */
  realScore: number;
  /** 0–1 probability the image is AI-generated */
  aiScore: number;
  /** Human-readable label */
  label: "real" | "ai_generated";
  /** Wall-clock time for preprocessing + inference (ms) */
  inferenceMs: number;
}

// ─── Preprocessing ────────────────────────────────────────────────────────────

/**
 * Converts a raw image buffer → normalized Float32Array
 * in CHW layout (Channels × Height × Width) as expected by the ViT model.
 *
 * Pipeline: decode → resize 224×224 → extract RGB pixels → normalize → CHW
 */
async function preprocessImage(imageBuffer: Buffer): Promise<Float32Array> {
  // sharp decodes JPEG/PNG/WEBP/AVIF — all in one call, no tmp files
  const { data } = await sharp(imageBuffer)
    .resize(IMAGE_SIZE, IMAGE_SIZE, {
      fit: "fill",        // exact 224×224, no letterboxing
      kernel: "lanczos3", // highest quality downsampling kernel
    })
    .removeAlpha()        // drop alpha channel if present (PNG, WEBP)
    .raw()                // give us raw RGBA→RGB uint8 bytes
    .toBuffer({ resolveWithObject: true });

  // data is a Buffer of uint8 RGB pixels, length = 224*224*3
  const float32 = new Float32Array(TENSOR_LEN);

  /**
   * Layout: sharp gives us HWC (row-major RGB).
   * ONNX ViT expects CHW: all R channel first, then G, then B.
   *
   * For pixel at (h, w):
   *   R → float32[0 * 224*224 + h*224 + w]
   *   G → float32[1 * 224*224 + h*224 + w]
   *   B → float32[2 * 224*224 + h*224 + w]
   */
  const planeSize = IMAGE_SIZE * IMAGE_SIZE; // 50,176

  for (let i = 0; i < planeSize; i++) {
    const srcIdx = i * CHANNELS; // HWC source index
    for (let c = 0; c < CHANNELS; c++) {
      // Normalize: (pixel/255 - mean) / std
      float32[c * planeSize + i] =
        (data[srcIdx + c] / 255.0 - NORM_MEAN[c]) / NORM_STD[c];
    }
  }

  return float32;
}

// ─── Softmax ──────────────────────────────────────────────────────────────────

/**
 * Numerically stable softmax.
 * Subtracts max before exp() to prevent float overflow.
 */
function softmax(logits: number[]): number[] {
  const max   = Math.max(...logits);
  const exps  = logits.map((x) => Math.exp(x - max));
  const sum   = exps.reduce((a, b) => a + b, 0);
  return exps.map((e) => e / sum);
}

// ─── Main Inference Function ───────────────────────────────────────────────────

/**
 * Runs end-to-end VeriFace inference on a raw image buffer.
 *
 * @example
 *   import { runOnnxInference } from "./onnxInference";
 *   const result = await runOnnxInference(req.file.buffer);
 *   // → { aiScore: 0.94, realScore: 0.06, label: "ai_generated", inferenceMs: 340 }
 */
export async function runOnnxInference(imageBuffer: Buffer): Promise<OnnxResult> {
  const t0 = Date.now();

  // 1. Get or initialize the session
  const session = await getSession();

  // 2. Preprocess image → Float32Array in CHW layout
  const pixelData = await preprocessImage(imageBuffer);

  // 3. Build ONNX tensor  [batch=1, channels=3, height=224, width=224]
  const tensor = new ort.Tensor("float32", pixelData, [1, CHANNELS, IMAGE_SIZE, IMAGE_SIZE]);

  // 4. Run inference
  const feeds: Record<string, ort.Tensor> = { pixel_values: tensor };
  const results = await session.run(feeds);

  // 5. Extract logits  (shape: [1, 2])
  const logitsTensor = results["logits"];
  const rawLogits    = Array.from(logitsTensor.data as Float32Array);
  // rawLogits[0] = real logit,  rawLogits[1] = ai_generated logit

  // 6. Softmax → probabilities
  const [realScore, aiScore] = softmax(rawLogits);

  const inferenceMs = Date.now() - t0;

  return {
    realScore,
    aiScore,
    label: aiScore >= 0.5 ? "ai_generated" : "real",
    inferenceMs,
  };
}
