"""
VeriFace ONNX Export Script
============================
Converts the fine-tuned PyTorch ViT model to a fully optimized .onnx file
for CPU inference via onnxruntime-node in the TypeScript backend.

Install deps:
  pip install torch transformers onnx onnxruntime onnxsim

Usage:
  python export_onnx.py --model_dir ./veriface-vit-finetuned --output ./model/veriface.onnx
"""

import argparse
import torch
import numpy as np
import onnx
import onnxruntime as ort
from onnxsim import simplify
from transformers import ViTForImageClassification, ViTImageProcessor
from pathlib import Path

# ─────────────────────────────────────────────
# ARGS
# ─────────────────────────────────────────────
parser = argparse.ArgumentParser()
parser.add_argument("--model_dir", type=str, default="./veriface-vit-finetuned",
                    help="Path to the fine-tuned HuggingFace model directory")
parser.add_argument("--output",    type=str, default="./model/veriface.onnx",
                    help="Output path for the .onnx file")
parser.add_argument("--opset",     type=int, default=17,
                    help="ONNX opset version (17 is recommended for ViT)")
args = parser.parse_args()

Path(args.output).parent.mkdir(parents=True, exist_ok=True)

# ─────────────────────────────────────────────
# LOAD MODEL
# ─────────────────────────────────────────────
print(f"📦 Loading model from: {args.model_dir}")
model = ViTForImageClassification.from_pretrained(args.model_dir)
model.eval()
model.cpu()

# ─────────────────────────────────────────────
# DUMMY INPUT  (batch=1, 3 channels, 224x224)
# ─────────────────────────────────────────────
dummy_input = torch.randn(1, 3, 224, 224)

# ─────────────────────────────────────────────
# EXPORT TO ONNX
# ─────────────────────────────────────────────
print(f"⚙️  Exporting to ONNX (opset {args.opset})...")
torch.onnx.export(
    model,
    dummy_input,
    args.output,
    opset_version=args.opset,
    input_names=["pixel_values"],
    output_names=["logits"],
    dynamic_axes={
        "pixel_values": {0: "batch_size"},   # allow variable batch sizes
        "logits":       {0: "batch_size"},
    },
    do_constant_folding=True,   # folds constants for speed gains
    export_params=True,
)
print(f"✅ Raw ONNX exported to: {args.output}")

# ─────────────────────────────────────────────
# SIMPLIFY (removes redundant nodes, ~20% smaller)
# ─────────────────────────────────────────────
print("🔧 Running onnx-simplifier...")
model_onnx = onnx.load(args.output)
model_simplified, check = simplify(model_onnx)
assert check, "❌ Simplified ONNX model check failed!"
onnx.save(model_simplified, args.output)
print(f"✅ Simplified ONNX saved ({Path(args.output).stat().st_size / 1e6:.1f} MB)")

# ─────────────────────────────────────────────
# VERIFY — run a test inference
# ─────────────────────────────────────────────
print("🧪 Verifying ONNX inference...")
sess_opts = ort.SessionOptions()
sess_opts.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
session = ort.InferenceSession(args.output, sess_options=sess_opts)

dummy_np = dummy_input.numpy()
outputs  = session.run(["logits"], {"pixel_values": dummy_np})
logits   = outputs[0][0]                          # shape: [2]
probs    = np.exp(logits) / np.sum(np.exp(logits))  # softmax
print(f"✅ Test inference OK — Real: {probs[0]*100:.1f}%  AI: {probs[1]*100:.1f}%")
print(f"\n🎉 Export complete! Drop {args.output} into your TypeScript backend.")
print(    "   Set MODEL_PATH env var and you're live.")
