"""
VeriFace ML Training Script
===========================
Base Model : google/vit-base-patch16-224
Task       : Binary classification — Real (0) vs AI-Generated (1)
Framework  : HuggingFace Transformers + PyTorch

Install deps:
  pip install transformers datasets torch torchvision accelerate scikit-learn pillow

Recommended Datasets (covers 50+ AI generators):
  - "elsaEU/ELSA_1M"                  → 1M real vs AI (SD, MJ, DALL-E, Firefly, etc.)
  - "haywoodsloan/ai-images-extended"  → Wide generator coverage incl. Flux.1, Ideogram
  - "poloclub/diffusiondb"             → Stable Diffusion prompts + images
  - "competitions/deepfake-detection"  → Face-focused deepfakes (GAN-heavy)
  - "Wissam42/AI-generated-images"     → Midjourney v5/v6 + DALL-E 3 + Firefly
  Combine all via `datasets.concatenate_datasets` for maximum coverage.
"""

import os
import torch
import numpy as np
from dataclasses import dataclass
from typing import Dict

from datasets import load_dataset, concatenate_datasets, DatasetDict
from transformers import (
    ViTForImageClassification,
    ViTImageProcessor,
    TrainingArguments,
    Trainer,
    EarlyStoppingCallback,
)
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
from PIL import Image

# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────
@dataclass
class CFG:
    base_model: str   = "google/vit-base-patch16-224"
    output_dir: str   = "./veriface-vit-finetuned"
    num_labels: int   = 2                    # 0 = Real, 1 = AI Generated
    image_size: int   = 224
    batch_size: int   = 32
    lr: float         = 2e-5
    weight_decay: float = 0.01
    epochs: int       = 10
    warmup_ratio: float = 0.1
    seed: int         = 42
    fp16: bool        = torch.cuda.is_available()
    label2id: Dict    = None
    id2label: Dict    = None

    def __post_init__(self):
        self.label2id = {"real": 0, "ai_generated": 1}
        self.id2label = {0: "real", 1: "ai_generated"}

cfg = CFG()
torch.manual_seed(cfg.seed)

# ─────────────────────────────────────────────
# LOAD & MERGE DATASETS
# ─────────────────────────────────────────────
print("📦 Loading datasets...")

# Primary dataset: ELSA_1M is the best single source for broad AI model coverage
ds_elsa = load_dataset("elsaEU/ELSA_1M", split="train[:80000]")

# Secondary: Wissam42 for latest Midjourney v6, DALL-E 3, Firefly
ds_wissam = load_dataset("Wissam42/AI-generated-images", split="train[:20000]")

# Merge — ensure both have "image" (PIL) and "label" (int) columns
# Normalize column names if needed per dataset schema
combined = concatenate_datasets([ds_elsa, ds_wissam])
combined = combined.shuffle(seed=cfg.seed)

# Train / Val split: 90 / 10
split = combined.train_test_split(test_size=0.1, seed=cfg.seed)
dataset = DatasetDict({"train": split["train"], "validation": split["test"]})
print(f"✅ Train: {len(dataset['train'])} | Val: {len(dataset['validation'])}")

# ─────────────────────────────────────────────
# PREPROCESSOR
# ─────────────────────────────────────────────
processor = ViTImageProcessor.from_pretrained(cfg.base_model)

def preprocess(batch):
    """Resize, normalize, return pixel_values + labels."""
    images = [img.convert("RGB") if img.mode != "RGB" else img for img in batch["image"]]
    inputs = processor(images=images, return_tensors="pt")
    inputs["labels"] = batch["label"]
    return inputs

dataset = dataset.map(
    preprocess,
    batched=True,
    batch_size=64,
    remove_columns=dataset["train"].column_names,
)
dataset.set_format("torch")

# ─────────────────────────────────────────────
# MODEL
# ─────────────────────────────────────────────
print(f"🧠 Loading base model: {cfg.base_model}")
model = ViTForImageClassification.from_pretrained(
    cfg.base_model,
    num_labels=cfg.num_labels,
    id2label=cfg.id2label,
    label2id=cfg.label2id,
    ignore_mismatched_sizes=True,   # replaces the classification head
)

# ─────────────────────────────────────────────
# METRICS
# ─────────────────────────────────────────────
def compute_metrics(eval_pred):
    logits, labels = eval_pred
    probs = torch.softmax(torch.tensor(logits), dim=-1).numpy()
    preds = np.argmax(probs, axis=1)
    ai_probs = probs[:, 1]
    return {
        "accuracy": accuracy_score(labels, preds),
        "f1":       f1_score(labels, preds, average="weighted"),
        "auc":      roc_auc_score(labels, ai_probs),
    }

# ─────────────────────────────────────────────
# TRAINING ARGS
# ─────────────────────────────────────────────
training_args = TrainingArguments(
    output_dir=cfg.output_dir,
    num_train_epochs=cfg.epochs,
    per_device_train_batch_size=cfg.batch_size,
    per_device_eval_batch_size=cfg.batch_size,
    learning_rate=cfg.lr,
    weight_decay=cfg.weight_decay,
    warmup_ratio=cfg.warmup_ratio,
    fp16=cfg.fp16,
    evaluation_strategy="epoch",
    save_strategy="epoch",
    load_best_model_at_end=True,
    metric_for_best_model="auc",
    greater_is_better=True,
    logging_dir="./logs",
    logging_steps=50,
    dataloader_num_workers=4,
    report_to="none",         # swap to "wandb" if you want experiment tracking
    seed=cfg.seed,
)

# ─────────────────────────────────────────────
# TRAINER
# ─────────────────────────────────────────────
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=dataset["train"],
    eval_dataset=dataset["validation"],
    compute_metrics=compute_metrics,
    callbacks=[EarlyStoppingCallback(early_stopping_patience=3)],
)

print("🚀 Starting fine-tuning...")
trainer.train()

print(f"💾 Saving model to {cfg.output_dir}")
trainer.save_model(cfg.output_dir)
processor.save_pretrained(cfg.output_dir)
print("✅ Training complete!")
