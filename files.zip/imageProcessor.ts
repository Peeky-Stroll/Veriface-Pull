/**
 * VeriFace — Heuristic Image Processor
 * ======================================
 * Two lightweight, purely algorithmic signals that complement the ONNX model.
 * These back the "Pixel-Level Analysis" marketing claims with real math.
 *
 *  • computeELA()             — Error Level Analysis (JPEG compression artifacts)
 *  • computeFrequencyScore()  — High-frequency noise detection via DCT-approximation
 *
 * Both functions accept a raw image Buffer and return a normalized [0, 1] score
 * where higher = more likely AI-generated.
 *
 * npm install sharp
 */

import sharp, { Sharp } from "sharp";

// ─── Constants ────────────────────────────────────────────────────────────────

/** ELA re-compression quality. Lower = more aggressive artifact detection. */
const ELA_QUALITY = 75;

/** Analysis resolution — small enough for speed, large enough for signal */
const ANALYSIS_SIZE = 128;

// ─── Types ────────────────────────────────────────────────────────────────────

export interface ELAResult {
  /** Mean absolute difference across all pixels after re-compression */
  meanDiff: number;
  /** Normalized score [0,1] — higher = more uniform compression (AI signal) */
  elaScore: number;
}

export interface FrequencyResult {
  /** Mean high-frequency energy across 8×8 DCT-approximation blocks */
  meanHighFreq: number;
  /** Normalized score [0,1] — higher = excessive smoothness (AI signal) */
  frequencyScore: number;
}

// ─── Shared Helper ────────────────────────────────────────────────────────────

/** Returns a 128×128 RGB uint8 Buffer. Reused across both analysis functions. */
async function toSmallRgb(buffer: Buffer): Promise<{ data: Buffer; width: number; height: number }> {
  const { data, info } = await sharp(buffer)
    .resize(ANALYSIS_SIZE, ANALYSIS_SIZE, { fit: "fill", kernel: "lanczos3" })
    .removeAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true });

  return { data, width: info.width, height: info.height };
}

// ─── ELA ──────────────────────────────────────────────────────────────────────

/**
 * Error Level Analysis (ELA)
 * --------------------------
 * Concept: Re-compress the image at a known quality level. Regions that were
 * already compressed heavily (authentic photos with natural noise) will show
 * HIGH residual differences. Regions that are synthetically smooth and uniform
 * (AI-generated) will show VERY LOW differences — they're already "converged".
 *
 * High elaScore → suspiciously uniform → likely AI-generated.
 *
 * Note: True ELA needs JPEG round-tripping. We approximate it with sharp:
 *   original → JPEG encode at Q=75 → decode → pixel diff
 */
export async function computeELA(buffer: Buffer): Promise<ELAResult> {
  // Step 1: Get original pixels at analysis resolution
  const { data: originalData, width, height } = await toSmallRgb(buffer);

  // Step 2: Re-encode to JPEG at ELA_QUALITY, then decode back to raw pixels
  const recompressedBuffer = await sharp(buffer)
    .resize(ANALYSIS_SIZE, ANALYSIS_SIZE, { fit: "fill", kernel: "lanczos3" })
    .removeAlpha()
    .jpeg({ quality: ELA_QUALITY, mozjpeg: true })
    .toBuffer();

  const { data: recompressedData } = await sharp(recompressedBuffer)
    .raw()
    .toBuffer({ resolveWithObject: true });

  // Step 3: Compute mean absolute difference across all channels
  const pixelCount = width * height * 3; // 128×128×3 = 49,152 values
  let totalDiff = 0;

  for (let i = 0; i < pixelCount; i++) {
    totalDiff += Math.abs(originalData[i] - recompressedData[i]);
  }

  const meanDiff = totalDiff / pixelCount;

  /**
   * Calibration:
   *  - Real photos       → meanDiff typically 8–25 (lots of natural variation)
   *  - AI images         → meanDiff typically 1–8  (over-smooth, already "converged")
   *  - Pure flat color   → meanDiff ≈ 0
   *
   * We invert and normalize: low diff → high ELA score (AI signal).
   * Clamp input to [0, 30] before normalizing.
   */
  const DIFF_MAX = 30.0;
  const clampedDiff = Math.min(meanDiff, DIFF_MAX);
  const elaScore = 1.0 - clampedDiff / DIFF_MAX; // invert: low diff = high score

  return { meanDiff, elaScore: Math.max(0, Math.min(1, elaScore)) };
}

// ─── FREQUENCY SCORE ──────────────────────────────────────────────────────────

/**
 * High-Frequency Noise Analysis (DCT approximation)
 * --------------------------------------------------
 * Concept: Real camera images have natural sensor noise distributed across
 * ALL frequency bands — including very high frequencies.
 *
 * AI diffusion models (trained on perceptual losses) tend to:
 *   a) Over-smooth high frequencies → images look "too clean"
 *   b) Add repeating texture patterns that concentrate energy at specific freqs
 *
 * True 2D-DCT is expensive. We approximate it with a high-pass spatial filter:
 * subtract a blurred copy from the original → residual = high-frequency content.
 *
 * Low frequencyScore → image is "too smooth" → likely AI-generated.
 *
 * NOTE: This flips intuition — we score LOW frequency as HIGH AI-probability.
 */
export async function computeFrequencyScore(buffer: Buffer): Promise<FrequencyResult> {
  // Step 1: Get grayscale for frequency analysis (luminance channel only)
  const { data: grayData, width, height } = await (async () => {
    const { data, info } = await sharp(buffer)
      .resize(ANALYSIS_SIZE, ANALYSIS_SIZE, { fit: "fill", kernel: "lanczos3" })
      .grayscale()
      .raw()
      .toBuffer({ resolveWithObject: true });
    return { data, width: info.width, height: info.height };
  })();

  // Step 2: Apply a strong Gaussian blur to get the low-frequency component
  // sharp's blur sigma=4 removes ~all spatial frequencies above ~8px period
  const blurredBuffer = await sharp(buffer)
    .resize(ANALYSIS_SIZE, ANALYSIS_SIZE, { fit: "fill", kernel: "lanczos3" })
    .grayscale()
    .blur(4)              // sigma=4 → strong blur → pure low-frequency
    .raw()
    .toBuffer();

  // Step 3: Residual = original - blurred = HIGH FREQUENCY content
  const pixelCount = width * height;
  let totalHighFreq = 0;

  for (let i = 0; i < pixelCount; i++) {
    const residual = Math.abs(grayData[i] - blurredBuffer[i]);
    totalHighFreq += residual;
  }

  const meanHighFreq = totalHighFreq / pixelCount;

  /**
   * Calibration:
   *  - Real photos (camera noise)  → meanHighFreq ≈ 12–35+
   *  - AI images (over-smooth)     → meanHighFreq ≈ 2–12
   *  - Cartoon / flat art           → meanHighFreq ≈ 0–5
   *
   * We normalize to [0,1] where LOW high-freq → HIGH AI score.
   * Clamp input to [0, 40].
   */
  const HF_MAX = 40.0;
  const clampedHF = Math.min(meanHighFreq, HF_MAX);
  const normalizedHF = clampedHF / HF_MAX;

  // Invert: low real-world HF energy → high AI probability
  const frequencyScore = 1.0 - normalizedHF;

  return {
    meanHighFreq,
    frequencyScore: Math.max(0, Math.min(1, frequencyScore)),
  };
}
