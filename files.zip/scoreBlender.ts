/**
 * VeriFace — Final Score Blender
 * ================================
 * Fuses three independent signals into one authoritative 0–100 verdict:
 *
 *   1. ONNX Model score    (primary signal — 70% weight)
 *   2. ELA score           (compression analysis — 15% weight)
 *   3. Frequency score     (noise analysis — 15% weight)
 *
 * The weighted blend prevents any single signal from dominating while
 * keeping the ONNX model as the primary authority.
 *
 * Also produces a human-readable explanation string for the frontend.
 */

import { runOnnxInference, OnnxResult } from "./onnxInference";
import { computeELA, computeFrequencyScore, ELAResult, FrequencyResult } from "./imageProcessor";

// ─── Weights ──────────────────────────────────────────────────────────────────

const WEIGHT_ONNX = 0.70;
const WEIGHT_ELA  = 0.15;
const WEIGHT_FREQ = 0.15;

// ─── Types ────────────────────────────────────────────────────────────────────

export interface VeriFaceResult {
  /** 0–100 final confidence that this image is AI-generated */
  aiConfidence: number;
  /** 0–100 final confidence that this image is real */
  realConfidence: number;
  /** Human-readable verdict */
  label: "ai_generated" | "real";
  /** Explanation for the frontend result card */
  explanation: string;
  /** Breakdown of individual signals for transparency */
  signals: {
    modelScore:     number; // 0–1
    elaScore:       number; // 0–1
    frequencyScore: number; // 0–1
    blendedRaw:     number; // 0–1 before rounding
  };
  /** Total wall-clock time in ms */
  totalMs: number;
}

// ─── Explanation Generator ────────────────────────────────────────────────────

function buildExplanation(
  label: "ai_generated" | "real",
  aiConfidence: number,
  ela: ELAResult,
  freq: FrequencyResult
): string {
  if (label === "ai_generated") {
    const reasons: string[] = [];

    if (ela.elaScore > 0.6)
      reasons.push(
        `JPEG compression artifacts are suspiciously uniform (ELA diff: ${ela.meanDiff.toFixed(1)})`
      );
    if (freq.frequencyScore > 0.6)
      reasons.push(
        `high-frequency noise is below natural camera levels (HF energy: ${freq.meanHighFreq.toFixed(1)})`
      );
    if (aiConfidence > 85)
      reasons.push("the pixel distribution strongly matches known AI generation signatures");

    const reasonStr =
      reasons.length > 0
        ? `Detected signals: ${reasons.join("; ")}.`
        : "The model detected generation artifacts consistent with diffusion or GAN synthesis.";

    return `VeriFace is ${aiConfidence}% confident this is AI-generated. ${reasonStr}`;
  } else {
    const reasons: string[] = [];

    if (ela.elaScore < 0.4)
      reasons.push(`natural JPEG compression variation (ELA diff: ${ela.meanDiff.toFixed(1)})`);
    if (freq.frequencyScore < 0.4)
      reasons.push(`camera-like high-frequency noise (HF energy: ${freq.meanHighFreq.toFixed(1)})`);

    const reasonStr =
      reasons.length > 0
        ? `Signals detected: ${reasons.join("; ")}.`
        : "No AI generation patterns were found in the pixel structure.";

    return `VeriFace is ${100 - aiConfidence}% confident this is an authentic photograph. ${reasonStr}`;
  }
}

// ─── Main Blender ─────────────────────────────────────────────────────────────

/**
 * Primary entry point for the Express /upload route.
 *
 * Runs all three signals in parallel for maximum speed, then blends.
 *
 * @example
 *   import { analyzeImage } from "./scoreBlender";
 *   const result = await analyzeImage(req.file.buffer);
 *   res.json(result);
 */
export async function analyzeImage(imageBuffer: Buffer): Promise<VeriFaceResult> {
  const t0 = Date.now();

  // ── Run all three signals in PARALLEL (not sequentially) ──────────────────
  // This is the key to staying under 2 seconds: ELA + frequency run
  // concurrently with ONNX inference. Total time ≈ max(individual times).
  const [onnx, ela, freq] = await Promise.all([
    runOnnxInference(imageBuffer),
    computeELA(imageBuffer),
    computeFrequencyScore(imageBuffer),
  ]);

  // ── Weighted blend ────────────────────────────────────────────────────────
  //    All three scores are normalized [0,1] where 1.0 = AI signal
  const blendedRaw =
    WEIGHT_ONNX * onnx.aiScore +
    WEIGHT_ELA  * ela.elaScore +
    WEIGHT_FREQ * freq.frequencyScore;

  // Clamp to [0, 1] — floating point arithmetic can drift slightly
  const blendedClamped = Math.max(0, Math.min(1, blendedRaw));

  // Convert to 0–100 integer for the frontend
  const aiConfidence   = Math.round(blendedClamped * 100);
  const realConfidence = 100 - aiConfidence;

  const label: "ai_generated" | "real" = aiConfidence >= 50 ? "ai_generated" : "real";

  const explanation = buildExplanation(label, aiConfidence, ela, freq);

  return {
    aiConfidence,
    realConfidence,
    label,
    explanation,
    signals: {
      modelScore:     onnx.aiScore,
      elaScore:       ela.elaScore,
      frequencyScore: freq.frequencyScore,
      blendedRaw,
    },
    totalMs: Date.now() - t0,
  };
}
